{{-- <x-guest-layout>
    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <div class="py-16">
        <div class="flex bg-white rounded-lg shadow-lg overflow-hidden mx-auto max-w-sm lg:max-w-4xl">
            <!-- Image Section - Hidden on mobile, visible on large screens -->
            <div class="hidden lg:block lg:w-1/2 bg-contain bg-center bg-no-repeat h-auto" style="height: 100%;"
                style="background-image:url('https://images.unsplash.com/photo-1546514714-df0ccc50d7bf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80')">
            </div>

            <!-- Form Section -->
            <div class="w-full p-8 lg:w-1/2">
                <h2 class="text-2xl font-semibold text-gray-700 text-center">Brand</h2>
                <p class="text-xl text-gray-600 text-center">Welcome back!</p>

                <!-- Google Sign In Button (Optional - hapus jika tidak digunakan) -->
                <a href="#" class="flex items-center justify-center mt-4 text-white rounded-lg shadow-md hover:bg-gray-100">
                    <div class="px-4 py-3">
                        <svg class="h-6 w-6" viewBox="0 0 40 40">
                            <path d="M36.3425 16.7358H35V16.6667H20V23.3333H29.4192C28.045 27.2142 24.3525 30 20 30C14.4775 30 10 25.5225 10 20C10 14.4775 14.4775 9.99999 20 9.99999C22.5492 9.99999 24.8683 10.9617 26.6342 12.5325L31.3483 7.81833C28.3717 5.04416 24.39 3.33333 20 3.33333C10.7958 3.33333 3.33335 10.7958 3.33335 20C3.33335 29.2042 10.7958 36.6667 20 36.6667C29.2042 36.6667 36.6667 29.2042 36.6667 20C36.6667 18.8825 36.5517 17.7917 36.3425 16.7358Z" fill="#FFC107" />
                            <path d="M5.25497 12.2425L10.7308 16.2583C12.2125 12.59 15.8008 9.99999 20 9.99999C22.5491 9.99999 24.8683 10.9617 26.6341 12.5325L31.3483 7.81833C28.3716 5.04416 24.39 3.33333 20 3.33333C13.5983 3.33333 8.04663 6.94749 5.25497 12.2425Z" fill="#FF3D00" />
                            <path d="M20 36.6667C24.305 36.6667 28.2167 35.0192 31.1742 32.34L26.0159 27.975C24.3425 29.2425 22.2625 30 20 30C15.665 30 11.9842 27.2359 10.5975 23.3784L5.16254 27.5659C7.92087 32.9634 13.5225 36.6667 20 36.6667Z" fill="#4CAF50" />
                            <path d="M36.3425 16.7358H35V16.6667H20V23.3333H29.4192C28.7592 25.1975 27.56 26.805 26.0133 27.9758C26.0142 27.975 26.015 27.975 26.0158 27.9742L31.1742 32.3392C30.8092 32.6708 36.6667 28.3333 36.6667 20C36.6667 18.8825 36.5517 17.7917 36.3425 16.7358Z" fill="#1976D2" />
                        </svg>
                    </div>
                    <h1 class="px-4 py-3 w-5/6 text-center text-gray-600 font-bold">Sign in with Google</h1>
                </a>

                <!-- Divider -->
                <div class="mt-4 flex items-center justify-between">
                    <span class="border-b w-1/5 lg:w-1/4"></span>
                    <span class="text-xs text-center text-gray-500 uppercase">or login with email</span>
                    <span class="border-b w-1/5 lg:w-1/4"></span>
                </div>

                <!-- Login Form -->
                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <!-- Email Address -->
                    <div class="mt-4">
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">
                            {{ __('Email Address') }}
                        </label>
                        <input type="email" 
                               id="email" 
                               name="email"
                               value="{{ old('email') }}"
                               class="bg-gray-200 text-gray-700 focus:outline-none focus:shadow-outline border border-gray-300 rounded py-2 px-4 block w-full appearance-none @error('email') border-red-500 @enderror" 
                               required 
                               autofocus 
                               autocomplete="username" />
                        @error('email')
                            <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Password -->
                    <div class="mt-4">
                        <div class="flex justify-between">
                            <label for="password" class="block text-gray-700 text-sm font-bold mb-2">
                                {{ __('Password') }}
                            </label>
                            @if (Route::has('password.request'))
                                <a href="{{ route('password.request') }}" class="text-xs text-gray-500">
                                    {{ __('Forget Password?') }}
                                </a>
                            @endif
                        </div>
                        <input type="password" 
                               id="password" 
                               name="password"
                               class="bg-gray-200 text-gray-700 focus:outline-none focus:shadow-outline border border-gray-300 rounded py-2 px-4 block w-full appearance-none @error('password') border-red-500 @enderror" 
                               required 
                               autocomplete="current-password" />
                        @error('password')
                            <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Remember Me -->
                    <div class="mt-4">
                        <label class="inline-flex items-center">
                            <input id="remember_me" 
                                   type="checkbox" 
                                   name="remember"
                                   class="rounded border-gray-300 text-gray-700 shadow-sm focus:border-gray-300 focus:ring focus:ring-gray-200 focus:ring-opacity-50" />
                            <span class="ml-2 text-sm text-gray-600">{{ __('Remember me') }}</span>
                        </label>
                    </div>

                    <!-- Submit Button -->
                    <div class="mt-8">
                        <button type="submit" class="bg-gray-700 text-white font-bold py-2 px-4 w-full rounded hover:bg-gray-600">
                            {{ __('Login') }}
                        </button>
                    </div>

                    <!-- Sign Up Link -->
                    <div class="mt-4 flex items-center justify-between">
                        <span class="border-b w-1/5 md:w-1/4"></span>
                        <a href="{{ route('register') }}" class="text-xs text-gray-500 uppercase">or sign up</a>
                        <span class="border-b w-1/5 md:w-1/4"></span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-guest-layout> --}}

<x-guest-layout>
    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <div class="py-16">
        <div class="flex bg-white rounded-lg overflow-hidden mx-auto w-full max-w-none min-h-[450px]">

            <!-- Image Section -->
            <div class="hidden lg:flex lg:w-1/2 bg-cover bg-center"
                 style="background-image: url('https://images.unsplash.com/photo-1631478855207-dfbb98b2249a?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1470');">
            </div>

            <!-- Form Section -->
            <div class="w-full p-8 lg:w-1/2">
                 <!-- LOGO -->
                <div class="flex justify-center mb-4">
                    <img src="{{ asset('images/logo-baru.jpg') }}" 
                        alt="Logo" 
                        class="h-40 w-40 object-contain">
                </div>
                <h2 class="text-2xl font-semibold text-gray-700 text-center">SSB Mitra Surabaya</h2>
                <p class="text-xl text-gray-600 text-center">Welcome back!</p>

                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <!-- Email -->
                    <div class="mt-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">{{ __('Email Address') }}</label>
                        <input type="email" name="email" value="{{ old('email') }}" required autofocus autocomplete="username" class="bg-gray-100 text-gray-700 focus:outline-none border border-gray-300 rounded py-2 px-4 w-full @error('email') border-red-500 @enderror">
                        @error('email') <p class="text-sm text-red-600 mt-2">{{ $message }}</p> @enderror
                    </div>

                    <!-- Password -->
                    <div class="mt-4">
                        <div class="flex justify-between">
                            <label class="block text-gray-700 text-sm font-bold mb-2">{{ __('Password') }}</label>
                            @if (Route::has('password.request'))
                                <a href="{{ route('password.request') }}" class="text-xs text-gray-500">Forget Password?</a>
                            @endif
                        </div>
                        <input type="password" name="password" required autocomplete="current-password" class="bg-gray-100 text-gray-700 focus:outline-none border border-gray-300 rounded py-2 px-4 w-full @error('password') border-red-500 @enderror">
                        @error('password') <p class="text-sm text-red-600 mt-2">{{ $message }}</p> @enderror
                    </div>

                    <!-- Remember -->
                    <div class="mt-4">
                        <label class="inline-flex items-center">
                            <input type="checkbox" name="remember" class="rounded border-gray-300">
                            <span class="ml-2 text-sm text-gray-600">Remember me</span>
                        </label>
                    </div>

                    <!-- Button -->
                    <div class="mt-8">
                        <button type="submit" class="bg-green-600 text-white font-bold py-2 px-4 w-full rounded hover:bg-green-700">
                            Login
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</x-guest-layout>
