<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAPORAN EVALUASI ATLET - <?php echo e($atlet->nama); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Times+New+Roman&display=swap" rel="stylesheet">
    <style>
        /* Reset dan Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 12pt;
            line-height: 1.5;
            color: #000000;
            background-color: #ffffff;
            padding: 20mm;
            max-width: 210mm;
            margin: 0 auto;
        }
        
        /* Header dengan logo di kanan atas seperti gambar contoh */
        .header-container {
            position: relative;
            margin-bottom: 15mm;
        }
        
        .letterhead {
            border-bottom: 3px solid #000000;
            padding-bottom: 8mm;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 5mm;
        }
        
        .institution-info {
            flex: 1;
        }
        
        .institution-name {
            font-size: 16pt;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 2mm;
        }
        
        .institution-address {
            font-size: 11pt;
            margin-bottom: 1mm;
            line-height: 1.4;
        }
        
        .logo-container {
            width: 40mm;
            height: 40mm;
            margin-left: 10mm;
            border: 1px solid #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background-color: #f9f9f9;
        }
        
        .logo-placeholder {
            font-size: 9pt;
            color: #666;
            text-align: center;
            padding: 5mm;
        }
        
        .document-title {
            font-size: 14pt;
            font-weight: bold;
            text-transform: uppercase;
            margin-top: 5mm;
            padding-top: 3mm;
            border-top: 1px solid #000000;
            text-align: center;
            letter-spacing: 0.5px;
        }
        
        /* Informasi Laporan */
        .report-info {
            margin-bottom: 10mm;
            border: 1px solid #000000;
            padding: 5mm;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 2mm;
        }
        
        .info-label {
            width: 40mm;
            font-weight: bold;
        }
        
        .info-value {
            flex: 1;
        }
        
        /* Identitas Atlet */
        .student-header {
            text-align: center;
            margin-bottom: 10mm;
            padding-bottom: 5mm;
            border-bottom: 1px solid #000000;
        }
        
        .student-name {
            font-size: 16pt;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 3mm;
        }
        
        .student-details {
            font-size: 11pt;
        }
        
        /* Skor Utama */
        .main-score {
            text-align: center;
            margin: 15mm 0;
            padding: 8mm;
            border: 2px solid #000000;
            border-radius: 2mm;
        }
        
        .score-label {
            font-size: 11pt;
            font-weight: bold;
            margin-bottom: 3mm;
            text-transform: uppercase;
        }
        
        .score-value {
            font-size: 28pt;
            font-weight: bold;
            margin: 5mm 0;
        }
        
        .score-details {
            font-size: 11pt;
            margin-top: 3mm;
        }
        
        /* Section Header */
        .section-header {
            font-size: 12pt;
            font-weight: bold;
            text-transform: uppercase;
            margin: 10mm 0 5mm 0;
            padding-bottom: 2mm;
            border-bottom: 2px solid #000000;
            letter-spacing: 0.5px;
        }
        
        /* Tabel Kriteria - seperti layout dari gambar */
        .criteria-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10mm;
            font-size: 11pt;
            border: 2px solid #000000;
        }
        
        .criteria-table th {
            background-color: #f5f5f5;
            border: 1px solid #000000;
            padding: 4mm 2mm;
            text-align: center;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .criteria-table td {
            border: 1px solid #000000;
            padding: 3mm 2mm;
            vertical-align: middle;
        }
        
        .criteria-table .criterion-name {
            font-weight: bold;
        }
        
        .criteria-table .criterion-code {
            font-size: 10pt;
            color: #666666;
        }
        
        /* Styling untuk tabel seperti contoh gambar */
        .table-header-section {
            text-align: center;
            font-weight: bold;
            font-size: 13pt;
            padding: 3mm;
            background-color: #f0f0f0;
            border-bottom: 2px solid #000000;
        }
        
        .performance-rating {
            text-align: center;
            padding: 2mm 4mm;
            border-radius: 1mm;
            font-weight: bold;
            font-size: 10pt;
            display: inline-block;
            min-width: 40mm;
        }
        
        .rating-high {
            background-color: #d4edda;
            border: 1px solid #000000;
            color: #155724;
        }
        
        .rating-medium {
            background-color: #fff3cd;
            border: 1px solid #000000;
            color: #856404;
        }
        
        .rating-low {
            background-color: #f8d7da;
            border: 1px solid #000000;
            color: #721c24;
        }
        
        /* Analisis Kinerja */
        .performance-analysis {
            margin: 10mm 0;
        }
        
        .analysis-section {
            margin-bottom: 8mm;
        }
        
        .analysis-title {
            font-size: 11pt;
            font-weight: bold;
            margin-bottom: 3mm;
            text-transform: uppercase;
            border-bottom: 1px solid #000000;
            padding-bottom: 1mm;
        }
        
        .strength-title {
            border-color: #000000;
        }
        
        .weakness-title {
            border-color: #666666;
        }
        
        .analysis-list {
            margin-left: 5mm;
        }
        
        .analysis-list li {
            margin-bottom: 2mm;
            list-style-type: disc;
        }
        
        /* Kesimpulan */
        .conclusion-box {
            border: 1px solid #000000;
            padding: 8mm;
            margin: 15mm 0;
            background-color: #f9f9f9;
        }
        
        .conclusion-title {
            font-size: 12pt;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 5mm;
            text-align: center;
        }
        
        .conclusion-content {
            text-align: justify;
            line-height: 1.6;
        }
        
        .conclusion-content p {
            margin-bottom: 3mm;
            text-indent: 10mm;
        }
        
        /* Rekomendasi */
        .recommendations {
            margin: 10mm 0;
        }
        
        .recommendation-item {
            margin-bottom: 3mm;
            padding-left: 5mm;
            position: relative;
        }
        
        .recommendation-item::before {
            content: "•";
            position: absolute;
            left: 0;
            font-weight: bold;
        }
        
        /* Tanda Tangan */
        .signature-section {
            margin-top: 25mm;
        }
        
        .signature-grid {
            display: flex;
            justify-content: space-between;
            margin-top: 20mm;
        }
        
        .signature-box {
            text-align: center;
            width: 70mm;
        }
        
        .signature-line {
            width: 50mm;
            height: 1px;
            background-color: #000000;
            margin: 15mm auto 2mm;
        }
        
        .signature-name {
            font-weight: bold;
            margin-top: 2mm;
        }
        
        .signature-title {
            font-size: 10pt;
        }
        
        /* Footer */
        .document-footer {
            font-size: 9pt;
            text-align: center;
            margin-top: 15mm;
            padding-top: 3mm;
            border-top: 1px solid #000000;
            color: #666666;
        }
        
        /* Utility Classes */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-left { text-align: left; }
        .text-bold { font-weight: bold; }
        .mb-3 { margin-bottom: 3mm; }
        .mb-5 { margin-bottom: 5mm; }
        .mt-3 { margin-top: 3mm; }
        .mt-5 { margin-top: 5mm; }
        .page-break {
            page-break-before: always;
        }
        
        @media print {
            body {
                padding: 15mm;
            }
            .page-break {
                page-break-before: always;
                margin-top: 20mm;
            }
            .logo-container {
                border: 1px solid #000000;
            }
        }
    </style>
</head>
<body>
    <!-- Header dengan logo di kanan atas -->
    <div class="header-container">
        <div class="header-content">
            <div class="institution-info">
                <div class="institution-name">Akademi Sepak Bola Indonesia</div>
                <div class="institution-address">
                    Jl. Pendidikan No. 123, Jakarta Pusat 10110
                </div>
                <div class="institution-address">
                    Telp: (021) 123-4567 • Website: www.ars-academy.id
                </div>
                <div class="institution-address">
                    Email: info@ars-academy.id
                </div>
            </div>
            
            <!-- Logo di kanan atas -->
            <div class="logo-container">
                <!-- Logo dari lokal -->
                <img src="<?php echo e(asset('images/logo-baru.png')); ?>" 
                     alt="Logo Akademi" 
                     style="max-width: 100%; max-height: 100%; object-fit: contain;"
                     onerror="this.onerror=null; this.src='https://via.placeholder.com/150x150/000000/FFFFFF?text=LOGO';">
            </div>
        </div>
        
        <div class="document-title">
            LAPORAN EVALUASI PERKEMBANGAN ATLET
        </div>
    </div>

    <!-- Informasi Laporan -->
    <div class="report-info">
        <div class="info-row">
            <div class="info-label">Nomor Laporan</div>
            <div class="info-value">: LP/<?php echo e(date('Y')); ?>/<?php echo e(str_pad($atlet->id, 4, '0', STR_PAD_LEFT)); ?></div>
        </div>
        <div class="info-row">
            <div class="info-label">Tanggal Cetak</div>
            <div class="info-value">: <?php echo e(date('d F Y, H:i')); ?></div>
        </div>
        <div class="info-row">
            <div class="info-label">Periode Evaluasi</div>
            <div class="info-value">: Semester <?php echo e(date('n') <= 6 ? 'I' : 'II'); ?> Tahun <?php echo e(date('Y')); ?></div>
        </div>
        <div class="info-row">
            <div class="info-label">Jumlah Peserta</div>
            <div class="info-value">: <?php echo e(count($hasilPerangkingan)); ?> Atlet</div>
        </div>
    </div>

    <!-- Identitas Atlet -->
    <div class="student-header">
        <div class="student-name"><?php echo e($atlet->nama); ?></div>
        <div class="student-details">
            <?php echo e($atlet->cabang_olahraga); ?> • Umur: <?php echo e($atlet->umur); ?> Tahun • ID: <?php echo e($atlet->id); ?>

        </div>
    </div>

    <!-- Skor Evaluasi Utama -->
    <div class="main-score">
        <div class="score-label">Skor Evaluasi Komprehensif</div>
        <div class="score-value"><?php echo e(number_format($hasilAtlet['Ki'] * 100, 1)); ?></div>
        <div class="score-details">
            Peringkat: <strong>#<?php echo e($hasilAtlet['ranking']); ?></strong> dari <?php echo e(count($hasilPerangkingan)); ?> atlet • 
            Nilai Utility: <strong><?php echo e(number_format($hasilAtlet['Ki'], 4)); ?></strong>
        </div>
    </div>

    <!-- Kriteria Penilaian -->
    <div class="section-header">EVALUASI PER KRITERIA PENILAIAN</div>
    
    <!-- Header tabel seperti contoh gambar -->
    <div class="table-header-section">
        A. HASIL PENILAIAN KRITERIA
    </div>
    
    <table class="criteria-table">
        <thead>
            <tr>
                <th width="5%">NO</th>
                <th width="25%">KRITERIA PENILAIAN</th>
                <th width="15%">KODE</th>
                <th width="15%">BOBOT</th>
                <th width="15%">NILAI</th>
                <th width="25%">KINERJA</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $nilai = $nilaiAtlet['C' . $kriteria->id];
                $nilaiMaks = 0;
                foreach($matrixKeputusan as $row) {
                    if($row['atlet'] && isset($row['C' . $kriteria->id])) {
                        $nilaiMaks = max($nilaiMaks, $row['C' . $kriteria->id]);
                    }
                }
                $persentase = $nilaiMaks > 0 ? ($nilai / $nilaiMaks) * 100 : 0;
                
                if($persentase >= 80) {
                    $kategori = 'UNGGUL';
                    $indicator = 'rating-high';
                } elseif($persentase >= 60) {
                    $kategori = 'BAIK';
                    $indicator = 'rating-medium';
                } else {
                    $kategori = 'PERLU PERBAIKAN';
                    $indicator = 'rating-low';
                }
            ?>
            <tr>
                <td class="text-center"><?php echo e($index + 1); ?></td>
                <td>
                    <div class="criterion-name"><?php echo e($kriteria->nama_kriteria); ?></div>
                </td>
                <td class="text-center">
                    <strong><?php echo e($kriteria->kode_kriteria); ?></strong>
                    <div class="criterion-code">(<?php echo e($kriteria->jenis == 'benefit' ? 'Benefit' : 'Cost'); ?>)</div>
                </td>
                <td class="text-center"><?php echo e($kriteria->bobot); ?>%</td>
                <td class="text-center">
                    <strong><?php echo e(number_format($nilai, 2)); ?></strong>
                    <?php if($nilaiMaks > 0): ?>
                    <div style="font-size: 9pt; margin-top: 1mm;">
                        (<?php echo e(number_format($persentase, 1)); ?>%)
                    </div>
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <span class="performance-rating <?php echo e($indicator); ?>">
                        <?php echo e($kategori); ?>

                    </span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Analisis Kekuatan dan Kelemahan -->
    <?php
        $kekuatan = [];
        $kelemahan = [];
        
        foreach($kriterias as $kriteria) {
            $nilai = $nilaiAtlet['C' . $kriteria->id];
            $nilaiMaks = 0;
            foreach($matrixKeputusan as $row) {
                if($row['atlet'] && isset($row['C' . $kriteria->id])) {
                    $nilaiMaks = max($nilaiMaks, $row['C' . $kriteria->id]);
                }
            }
            $persentase = $nilaiMaks > 0 ? ($nilai / $nilaiMaks) * 100 : 0;
            
            if($persentase >= 80) {
                $kekuatan[] = [
                    'nama' => $kriteria->nama_kriteria,
                    'nilai' => $nilai,
                    'persen' => $persentase
                ];
            } elseif($persentase < 60) {
                $kelemahan[] = [
                    'nama' => $kriteria->nama_kriteria,
                    'nilai' => $nilai,
                    'persen' => $persentase
                ];
            }
        }
    ?>

    <!-- Header analisis seperti contoh gambar -->
    <div class="table-header-section" style="margin-top: 10mm;">
        B. ANALISIS PERFORMA
    </div>
    
    <div class="performance-analysis">
        <?php if(count($kekuatan) > 0): ?>
        <div class="analysis-section">
            <div class="analysis-title strength-title">1. KEKUATAN DAN PRESTASI</div>
            <ul class="analysis-list">
                <?php $__currentLoopData = $kekuatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong><?php echo e($item['nama']); ?></strong> dengan skor <?php echo e(number_format($item['nilai'], 2)); ?> 
                    (<?php echo e(number_format($item['persen'], 1)); ?>% dari nilai maksimal). 
                    Aspek ini menunjukkan kompetensi yang sangat baik.
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php if(count($kelemahan) > 0): ?>
        <div class="analysis-section">
            <div class="analysis-title weakness-title">2. AREA PERLU PERHATIAN</div>
            <ul class="analysis-list">
                <?php $__currentLoopData = $kelemahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong><?php echo e($item['nama']); ?></strong> dengan skor <?php echo e(number_format($item['nilai'], 2)); ?> 
                    (<?php echo e(number_format($item['persen'], 1)); ?>% dari nilai maksimal). 
                    Aspek ini memerlukan perhatian khusus untuk peningkatan performa.
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>

    <!-- Kesimpulan -->
    <div class="conclusion-box">
        <div class="conclusion-title">C. KESIMPULAN EVALUASI</div>
        <div class="conclusion-content">
            <p>
                Berdasarkan hasil analisis sistem evaluasi dengan Metode ARAS (Additive Ratio Assessment), 
                atlet <strong><?php echo e($atlet->nama); ?></strong> telah mencapai skor evaluasi komprehensif sebesar 
                <strong><?php echo e(number_format($hasilAtlet['Ki'] * 100, 1)); ?></strong> dari skala maksimal 100.
            </p>
            
            <p>
                Atlet berada pada <strong>peringkat ke-<?php echo e($hasilAtlet['ranking']); ?></strong> dari total 
                <?php echo e(count($hasilPerangkingan)); ?> peserta evaluasi. 
                
                <?php if($hasilAtlet['ranking'] == 1): ?>
                Prestasi ini menunjukkan bahwa atlet memiliki performa terbaik di antara seluruh peserta evaluasi.
                <?php elseif($hasilAtlet['ranking'] <= 3): ?>
                Prestasi ini menempatkan atlet dalam kelompok unggulan dengan potensi pengembangan yang sangat tinggi.
                <?php elseif($hasilAtlet['ranking'] <= ceil(count($hasilPerangkingan) / 2)): ?>
                Atlet menunjukkan performa yang memadai dengan beberapa aspek yang masih dapat ditingkatkan.
                <?php else: ?>
                Atlet memiliki ruang peningkatan yang signifikan untuk mencapai standar kompetensi yang optimal.
                <?php endif; ?>
            </p>
            
            <p>
                Secara keseluruhan, atlet menunjukkan perkembangan yang 
                <?php if($hasilAtlet['Ki'] >= 0.8): ?>
                <strong>sangat memuaskan</strong> dengan penguasaan kompetensi yang komprehensif.
                <?php elseif($hasilAtlet['Ki'] >= 0.6): ?>
                <strong>memuaskan</strong> dengan beberapa area yang memerlukan perhatian khusus.
                <?php else: ?>
                <strong>perlu peningkatan intensif</strong> untuk mencapai standar kompetensi yang diharapkan.
                <?php endif; ?>
            </p>
        </div>
    </div>

    <!-- Rekomendasi -->
    <div class="table-header-section">
        D. REKOMENDASI DAN TINDAK LANJUT
    </div>
    
    <div class="recommendations">
        <?php if($hasilAtlet['ranking'] == 1): ?>
        <div class="recommendation-item">
            Pertahankan konsistensi performa melalui program maintenance dan pengembangan berkelanjutan
        </div>
        <div class="recommendation-item">
            Fokus pada penguatan aspek mental dan strategi kompetisi untuk persiapan turnamen tingkat tinggi
        </div>
        <div class="recommendation-item">
            Berperan sebagai mentor bagi atlet junior untuk pengembangan kepemimpinan
        </div>
        <?php if(count($kelemahan) > 0): ?>
        <div class="recommendation-item">
            Optimalkan aspek <?php echo e($kelemahan[0]['nama']); ?> meskipun berada di peringkat teratas
        </div>
        <?php endif; ?>
        
        <?php elseif($hasilAtlet['ranking'] <= 3): ?>
        <div class="recommendation-item">
            Analisis komparatif dengan peringkat di atas untuk penyusunan strategi peningkatan yang tepat
        </div>
        <?php if(count($kelemahan) > 0): ?>
        <div class="recommendation-item">
            Program khusus untuk peningkatan <?php echo e($kelemahan[0]['nama']); ?> dengan target peningkatan 20% dalam 3 bulan
        </div>
        <?php endif; ?>
        <?php if(count($kekuatan) > 0): ?>
        <div class="recommendation-item">
            Optimalkan <?php echo e($kekuatan[0]['nama']); ?> sebagai keunggulan kompetitif yang dapat dikembangkan
        </div>
        <?php endif; ?>
        <div class="recommendation-item">
            Intensifikasi latihan dengan monitoring perkembangan setiap 2 minggu
        </div>
        
        <?php else: ?>
        <?php if(count($kelemahan) > 0): ?>
        <div class="recommendation-item">
            Program intensif untuk peningkatan <?php echo e($kelemahan[0]['nama']); ?> sebagai prioritas utama
        </div>
        <?php endif; ?>
        <?php if(count($kekuatan) > 0): ?>
        <div class="recommendation-item">
            Manfaatkan kompetensi <?php echo e($kekuatan[0]['nama']); ?> sebagai fondasi pengembangan aspek lain
        </div>
        <?php endif; ?>
        <div class="recommendation-item">
            Penyusunan program latihan individual dengan target peningkatan 25% dalam 3 bulan
        </div>
        <div class="recommendation-item">
            Evaluasi perkembangan mingguan dengan pelatih dan orang tua
        </div>
        <div class="recommendation-item">
            Studi banding dan pembelajaran dari atlet dengan peringkat lebih tinggi
        </div>
        <?php endif; ?>
        
        <div class="recommendation-item">
            Monitoring dan evaluasi berkala setiap bulan untuk penyesuaian program yang diperlukan
        </div>
        <div class="recommendation-item">
            Kolaborasi aktif antara orang tua, pelatih, dan atlet untuk support system optimal
        </div>
    </div>

    <!-- Tanda Tangan -->
    <div class="signature-section">
        <div class="signature-grid">
            <div class="signature-box">
                <div class="signature-line"></div>
                <div class="signature-name">Pelatih Utama</div>
                <div class="signature-title">Penanggung Jawab Evaluasi</div>
            </div>
            
            <div class="signature-box">
                <div class="signature-line"></div>
                <div class="signature-name">Kepala Akademi</div>
                <div class="signature-title">Penanggung Jawab Program</div>
            </div>
        </div>
        
        <div class="text-center mt-5">
            <div style="font-size: 10pt; margin-top: 5mm;">
                Bekasi, <?php echo e(date('d F Y')); ?>

            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="document-footer">
        <p>Laporan ini dicetak secara otomatis oleh Sistem Evaluasi ARAS Akademi Sepak Bola Indonesia</p>
        <p>Tanggal cetak: <?php echo e(date('d/m/Y H:i')); ?> • Halaman 1 dari 1</p>
        <p class="mt-3">
            <em>
                Dokumen ini merupakan bagian dari rapor perkembangan atlet dan digunakan untuk keperluan 
                evaluasi serta pembinaan atlet. Kerahasiaan dokumen ini diharapkan dapat dijaga.
            </em>
        </p>
    </div>
</body>
</html><?php /**PATH C:\laravel\spk-aras\resources\views/laporan/individu.blade.php ENDPATH**/ ?>