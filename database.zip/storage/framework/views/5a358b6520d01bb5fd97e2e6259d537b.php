<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight mt-6 mb-0">
                <?php echo e(__('Riwayat Aktivitas Sistem')); ?>

            </h2>
            <div class="text-sm text-gray-500 dark:text-gray-400">
                Log aktivitas pengguna
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Alert Success -->
            <?php if(session('success')): ?>
            <div class="mb-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-700 rounded-lg">
                <div class="flex items-center">
                    <svg class="w-5 h-5 me-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <?php
                    $totalAktivitas = $penilaians->count();
                    $totalAtlet = \App\Models\Atlet::count();
                    $totalKriteria = \App\Models\Kriteria::count();
                    $aktivitasHariIni = $penilaians->where('updated_at', '>=', \Carbon\Carbon::today())->count();
                ?>

                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border-gray-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Aktivitas</p>
                            <p class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?php echo e($totalAktivitas); ?></p>
                        </div>
                        <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                            <svg class="w-6 h-6 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border-gray-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Aktivitas Hari Ini</p>
                            <p class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?php echo e($aktivitasHariIni); ?></p>
                        </div>
                        <div class="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                            <svg class="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border-gray-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Atlet</p>
                            <p class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?php echo e($totalAtlet); ?></p>
                        </div>
                        <div class="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                            <svg class="w-6 h-6 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border-gray-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Kriteria</p>
                            <p class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?php echo e($totalKriteria); ?></p>
                        </div>
                        <div class="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                            <svg class="w-6 h-6 text-yellow-600 dark:text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 mb-6">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        Filter Riwayat
                    </h3>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <select id="filterAtlet" class="text-sm border border-gray-300 rounded-lg px-3 py-2 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                            <option value="">Semua Atlet</option>
                            <?php $__currentLoopData = \App\Models\Atlet::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($atlet->id); ?>"><?php echo e($atlet->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select id="filterKriteria" class="text-sm border border-gray-300 rounded-lg px-3 py-2 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                            <option value="">Semua Kriteria</option>
                            <?php $__currentLoopData = \App\Models\Kriteria::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kriteria->id); ?>"><?php echo e($kriteria->nama_kriteria); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button id="resetFilter" class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white text-sm rounded-lg transition">
                            Reset Filter
                        </button>
                    </div>
                </div>
            </div>

            <!-- Tabel Riwayat Penilaian -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            Riwayat Penilaian Terbaru
                        </h3>
                        <span class="text-sm text-gray-500 dark:text-gray-400">
                            <?php echo e($penilaians->total()); ?> entri ditemukan
                        </span>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" class="px-6 py-3">Atlet</th>
                                    <th scope="col" class="px-6 py-3">Kriteria</th>
                                    <th scope="col" class="px-6 py-3 text-center">Nilai</th>
                                    <th scope="col" class="px-6 py-3 text-center">Jenis</th>
                                    <th scope="col" class="px-6 py-3 text-center">Tanggal</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $penilaians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                    <td class="px-6 py-4 font-medium text-gray-900 dark:text-white">
                                        <div class="flex items-center gap-2">
                                            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center text-white text-xs font-bold">
                                                <?php echo e(strtoupper(substr($penilaian->atlet->nama, 0, 2))); ?>

                                            </div>
                                            <div>
                                                <div class="font-semibold"><?php echo e($penilaian->atlet->nama); ?></div>
                                                <div class="text-xs text-gray-500 dark:text-gray-400">
                                                    <?php echo e($penilaian->atlet->umur); ?> th
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-2">
                                            <span class="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs font-mono font-semibold">
                                                <?php echo e($penilaian->kriteria->kode_kriteria); ?>

                                            </span>
                                            <span class="text-xs text-gray-500">|</span>
                                            <span class="text-sm"><?php echo e($penilaian->kriteria->nama_kriteria); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full text-sm font-semibold">
                                            <?php echo e(number_format($penilaian->nilai, 2)); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e($penilaian->kriteria->jenis == 'benefit' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'); ?>">
                                            <?php echo e(ucfirst($penilaian->kriteria->jenis)); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-center text-xs text-gray-500 dark:text-gray-400">
                                        <div class="font-semibold"><?php echo e($penilaian->updated_at->format('d M Y')); ?></div>
                                        <div><?php echo e($penilaian->updated_at->format('H:i')); ?></div>
                                        <div class="text-xs text-gray-400 mt-1">
                                            <?php echo e($penilaian->updated_at->diffForHumans()); ?>

                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                                        <svg class="w-12 h-12 mx-auto mb-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                        </svg>
                                        <p class="text-lg font-medium mb-2">Belum ada data penilaian</p>
                                        <p class="text-sm">Mulai dengan menilai atlet dari menu Penilaian</p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($penilaians->hasPages()): ?>
                    <div class="mt-4">
                        <?php echo e($penilaians->links()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Additional Info -->
            <div class="mt-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <div class="flex items-start gap-3">
                    <svg class="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <div>
                        <h4 class="font-semibold text-blue-800 dark:text-blue-300 mb-1">Informasi Riwayat</h4>
                        <p class="text-sm text-blue-700 dark:text-blue-400">
                            Halaman ini menampilkan semua aktivitas penilaian yang dilakukan oleh pengguna sistem. 
                            Setiap perubahan nilai atlet akan tercatat secara otomatis untuk keperluan audit dan monitoring.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript untuk Filter -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const filterAtlet = document.getElementById('filterAtlet');
            const filterKriteria = document.getElementById('filterKriteria');
            const resetFilter = document.getElementById('resetFilter');

            // Simpan state filter di URL
            function updateFilters() {
                const params = new URLSearchParams();
                
                if (filterAtlet.value) {
                    params.set('atlet_id', filterAtlet.value);
                }
                
                if (filterKriteria.value) {
                    params.set('kriteria_id', filterKriteria.value);
                }

                const queryString = params.toString();
                const newUrl = queryString ? `${window.location.pathname}?${queryString}` : window.location.pathname;
                
                window.location.href = newUrl;
            }

            filterAtlet.addEventListener('change', updateFilters);
            filterKriteria.addEventListener('change', updateFilters);

            resetFilter.addEventListener('click', function() {
                window.location.href = window.location.pathname;
            });

            // Set nilai filter dari URL
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('atlet_id')) {
                filterAtlet.value = urlParams.get('atlet_id');
            }
            if (urlParams.get('kriteria_id')) {
                filterKriteria.value = urlParams.get('kriteria_id');
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laravel\spk-aras\resources\views/riwayat/index.blade.php ENDPATH**/ ?>