<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center">
            <a href="<?php echo e(route('penilaian.index')); ?>" class="me-4 text-gray-600 hover:text-gray-800 dark:text-gray-400">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Input Penilaian Atlet')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            
            <?php if($kriterias->isEmpty()): ?>
            <!-- Alert Kriteria Kosong -->
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <svg class="w-6 h-6 text-red-500 me-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                    <div>
                        <h3 class="font-semibold text-red-800">Kriteria Belum Tersedia</h3>
                        <p class="text-red-700 text-sm">Silakan tambahkan kriteria penilaian terlebih dahulu sebelum melakukan penilaian atlet.</p>
                        <a href="<?php echo e(route('kriteria.create')); ?>" class="inline-block mt-2 text-sm text-red-800 underline hover:text-red-900">
                            Tambah Kriteria →
                        </a>
                    </div>
                </div>
            </div>
            <?php else: ?>

            <!-- Info Atlet -->
            <?php if($selectedAtlet): ?>
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-6">
                    <div class="flex items-center gap-4">
                        <div class="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-2xl">
                            <?php echo e(strtoupper(substr($selectedAtlet->nama, 0, 2))); ?>

                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-gray-900 dark:text-white"><?php echo e($selectedAtlet->nama); ?></h3>
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                <?php echo e($selectedAtlet->cabang_olahraga); ?> • <?php echo e($selectedAtlet->jenis_kelamin_lengkap); ?> • <?php echo e($selectedAtlet->umur); ?> tahun
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Form Penilaian -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm rounded-lg">
                <div class="p-6">
                    <form action="<?php echo e(route('penilaian.store')); ?>" method="POST" id="formPenilaian">
                        <?php echo csrf_field(); ?>

                        <!-- Pilih Atlet (jika belum dipilih) -->
                        <?php if(!$selectedAtlet): ?>
                        <div class="mb-6">
                            <label for="atlet_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                Pilih Atlet <span class="text-red-500">*</span>
                            </label>
                            <select name="atlet_id" id="atlet_id" onchange="window.location.href='<?php echo e(route('penilaian.create')); ?>?atlet_id=' + this.value"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
                                <option value="">-- Pilih Atlet --</option>
                                <?php $__currentLoopData = $atlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($atlet->id); ?>" <?php echo e(old('atlet_id') == $atlet->id ? 'selected' : ''); ?>>
                                    <?php echo e($atlet->nama); ?> - <?php echo e($atlet->cabang_olahraga); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['atlet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php else: ?>
                        <input type="hidden" name="atlet_id" value="<?php echo e($selectedAtlet->id); ?>">
                        <?php endif; ?>

                        <!-- Daftar Kriteria -->
                        <div class="mb-6">
                            <h4 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                                Penilaian Kriteria
                            </h4>
                            
                            <div class="space-y-4">
                                <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition">
                                    <div class="flex items-start justify-between mb-3">
                                        <div class="flex-1">
                                            <div class="flex items-center gap-2 mb-2">
                                                <span class="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-full text-sm font-mono font-semibold">
                                                    <?php echo e($kriteria->kode_kriteria); ?>

                                                </span>
                                                <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e($kriteria->jenis == 'benefit' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'); ?>">
                                                    <?php echo e(ucfirst($kriteria->jenis)); ?>

                                                </span>
                                            </div>
                                            <h5 class="font-semibold text-gray-900 dark:text-white mb-1">
                                                <?php echo e($kriteria->nama_kriteria); ?>

                                            </h5>
                                            <?php if($kriteria->keterangan): ?>
                                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                                <?php echo e($kriteria->keterangan); ?>

                                            </p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="text-right ml-4">
                                            <p class="text-xs text-gray-500 dark:text-gray-400">Bobot</p>
                                            <p class="text-lg font-bold text-blue-600 dark:text-blue-400"><?php echo e($kriteria->bobot); ?>%</p>
                                        </div>
                                    </div>

                                    <input type="hidden" name="penilaian[<?php echo e($index); ?>][kriteria_id]" value="<?php echo e($kriteria->id); ?>">
                                    
                                    <div class="relative">
                                        <input type="number" 
                                            name="penilaian[<?php echo e($index); ?>][nilai]" 
                                            id="nilai_<?php echo e($kriteria->id); ?>"
                                            value="<?php echo e(old('penilaian.'.$index.'.nilai', $existingPenilaian[$kriteria->id] ?? '')); ?>" 
                                            step="0.01" 
                                            min="0"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 placeholder-gray-400 dark:bg-gray-700 dark:border-gray-600 dark:text-white" 
                                            placeholder="Masukkan nilai" 
                                            required>
                                    </div>
                                    <?php $__errorArgs = ['penilaian.'.$index.'.nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Info Box -->
                        <div class="mb-6 p-4 bg-blue-50 border-l-4 border-blue-500 text-blue-700 rounded-lg dark:bg-blue-900 dark:text-blue-200">
                            <div class="flex items-start">
                                <svg class="w-5 h-5 me-2 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                                </svg>
                                <div class="text-sm">
                                    <p class="font-semibold mb-1">Catatan Penilaian:</p>
                                    <ul class="list-disc list-inside space-y-1">
                                        <li><strong>Benefit:</strong> Semakin tinggi nilai semakin baik</li>
                                        <li><strong>Cost:</strong> Semakin rendah nilai semakin baik</li>
                                        <li>Pastikan semua kriteria sudah dinilai</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- Buttons -->
                        <div class="flex items-center gap-3">
                            <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">
                                <svg class="w-5 h-5 inline me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                                Simpan Penilaian
                            </button>
                            <a href="<?php echo e(route('penilaian.index')); ?>" class="text-gray-700 bg-white border border-gray-300 hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-600 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-700">
                                Batal
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laravel\spk-aras\resources\views/penilaian/create.blade.php ENDPATH**/ ?>