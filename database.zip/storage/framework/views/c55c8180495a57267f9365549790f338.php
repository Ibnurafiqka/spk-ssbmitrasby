<?php if(auth()->check()): ?>
    <img src="<?php echo e(asset('images/logo-baru.jpg')); ?>" alt="Logo" style="width: 60px; height: 60px; margin-right: 1rem;">
<?php endif; ?><?php /**PATH C:\laravel\spk-aras\resources\views/components/application-logo.blade.php ENDPATH**/ ?>