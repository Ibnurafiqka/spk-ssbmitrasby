<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight mt-6 mb-0">
                <?php echo e(__('Hasil Perangkingan - Metode ARAS')); ?>

            </h2>
            <a href="<?php echo e(route('perangkingan.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white text-sm font-medium rounded-lg transition">
                <svg class="w-4 h-4 me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
                Kembali
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Alert Success -->
            <?php if(session('success')): ?>
            <div class="mb-6 p-4 bg-green-100 border-l-4 border-green-500 text-green-700 rounded-lg">
                <div class="flex items-center">
                    <svg class="w-5 h-5 me-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <!-- Info Card -->
            <div class="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg shadow-lg mb-6 p-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-4">
                        <div class="p-3 bg-white/20 rounded-lg">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-2xl font-bold mb-1">Perhitungan Selesai!</h3>
                            <p class="text-green-100">
                                Hasil perangkingan <?php echo e(count($hasilPerangkingan)); ?> atlet
                                <?php if($kelompokUmur && $kelompokUmur != 'all'): ?>
                                    <span class="font-semibold">(Kelompok Umur <?php echo e($kelompokUmur); ?> tahun)</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <a href="<?php echo e(route('laporan.index')); ?>" class="inline-flex items-center px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-lg transition">
                            <svg class="w-5 h-5 me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            Lihat Laporan
                        </a>
                        <a href="<?php echo e(route('laporan.pdf')); ?>" target="_blank" class="inline-flex items-center px-4 py-2 bg-white hover:bg-gray-100 text-green-600 font-semibold rounded-lg transition">
                            <svg class="w-5 h-5 me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            Export PDF
                        </a>
                    </div>
                </div>
            </div>

            <!-- Hasil Perangkingan Akhir -->
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-xl font-bold text-gray-900 dark:text-white">
                            🏆 Hasil Perangkingan Akhir
                        </h3>
                        <?php if($kelompokUmur && $kelompokUmur != 'all'): ?>
                        <span class="px-4 py-2 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-lg text-sm font-semibold">
                            Kelompok Umur: <?php echo e($kelompokUmur); ?> tahun
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" class="px-6 py-4 text-center">Ranking</th>
                                    <th scope="col" class="px-6 py-4">Nama Atlet</th>
                                    <th scope="col" class="px-6 py-4 text-center">Umur</th>
                                    <th scope="col" class="px-6 py-4">Cabang Olahraga</th>
                                    <th scope="col" class="px-6 py-4 text-center">Nilai Si</th>
                                    <th scope="col" class="px-6 py-4 text-center">Nilai Ki</th>
                                    <th scope="col" class="px-6 py-4 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $hasilPerangkingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600
                                    <?php echo e($hasil['ranking'] == 1 ? 'bg-yellow-50 dark:bg-yellow-900/20' : ''); ?>

                                    <?php echo e($hasil['ranking'] == 2 ? 'bg-gray-50 dark:bg-gray-900/20' : ''); ?>

                                    <?php echo e($hasil['ranking'] == 3 ? 'bg-orange-50 dark:bg-orange-900/20' : ''); ?>">
                                    <td class="px-6 py-4 text-center">
                                        <?php if($hasil['ranking'] == 1): ?>
                                            <div class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 text-white font-bold text-lg shadow-lg">
                                                1
                                            </div>
                                        <?php elseif($hasil['ranking'] == 2): ?>
                                            <div class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-gray-300 to-gray-500 text-white font-bold text-lg shadow-lg">
                                                2
                                            </div>
                                        <?php elseif($hasil['ranking'] == 3): ?>
                                            <div class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 text-white font-bold text-lg shadow-lg">
                                                3
                                            </div>
                                        <?php else: ?>
                                            <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold">
                                                <?php echo e($hasil['ranking']); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center text-white text-sm font-bold">
                                                <?php echo e(strtoupper(substr($hasil['atlet']->nama, 0, 2))); ?>

                                            </div>
                                            <div>
                                                <p class="font-semibold text-gray-900 dark:text-white">
                                                    <?php echo e($hasil['atlet']->nama); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs font-semibold">
                                            <?php echo e($hasil['atlet']->umur); ?> th
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-gray-900 dark:text-white">
                                        <?php echo e($hasil['atlet']->cabang_olahraga); ?>

                                    </td>
                                    <td class="px-6 py-4 text-center font-mono text-gray-900 dark:text-white">
                                        <?php echo e(number_format($hasil['Si'], 4)); ?>

                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="px-3 py-1 font-mono font-bold text-sm rounded-full
                                            <?php echo e($hasil['Ki'] >= 0.9 ? 'bg-green-100 text-green-800' : ($hasil['Ki'] >= 0.7 ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800')); ?>">
                                            <?php echo e(number_format($hasil['Ki'], 4)); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <a href="<?php echo e(route('laporan.individu', $hasil['atlet']->id)); ?>" 
                                           class="inline-flex items-center px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-xs font-medium rounded transition"
                                           title="Download PDF Individual">
                                            <svg class="w-4 h-4 me-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                            </svg>
                                            PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Kesimpulan -->
                    <div class="mt-6 p-4 bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500 rounded">
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            <strong>Kesimpulan:</strong> 
                            Berdasarkan hasil perhitungan metode ARAS
                            <?php if($kelompokUmur && $kelompokUmur != 'all'): ?>
                                untuk kelompok umur <?php echo e($kelompokUmur); ?> tahun
                            <?php endif; ?>
                            , atlet dengan peringkat tertinggi adalah 
                            <strong class="text-green-700 dark:text-green-400"><?php echo e($hasilPerangkingan[0]['atlet']->nama); ?></strong> 
                            dengan nilai Ki = <strong><?php echo e(number_format($hasilPerangkingan[0]['Ki'], 4)); ?></strong>.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Detail Perhitungan (Collapsible) -->
            <div class="space-y-4">
                
                <!-- Matrix Keputusan -->
                <details class="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                    <summary class="px-6 py-4 cursor-pointer font-semibold text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition">
                        📊 1. Matrix Keputusan
                    </summary>
                    <div class="px-6 pb-6">
                        <div class="overflow-x-auto mt-4">
                            <table class="w-full text-xs border-collapse">
                                <thead>
                                    <tr class="bg-gray-50 dark:bg-gray-700">
                                        <th class="border border-gray-300 dark:border-gray-600 px-3 py-2">Alternatif</th>
                                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="border border-gray-300 dark:border-gray-600 px-3 py-2">
                                            <?php echo e($kriteria->kode_kriteria); ?>

                                        </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-900 dark:text-white">
                                    <?php $__currentLoopData = $matrixKeputusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($index == 0 ? 'bg-yellow-50 dark:bg-yellow-900/20 font-semibold' : ''); ?>">
                                        <td class="border border-gray-300 dark:border-gray-600 px-3 py-2">
                                            <?php echo e($index == 0 ? 'A0 (Optimal)' : 'A' . $index . ' - ' . $row['atlet']->nama); ?>

                                        </td>
                                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="border border-gray-300 dark:border-gray-600 px-3 py-2 text-center">
                                            <?php echo e(number_format($row['C' . $kriteria->id], 2)); ?>

                                        </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Matrix Normalisasi -->
                <details class="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                    <summary class="px-6 py-4 cursor-pointer font-semibold text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition">
                        📐 2. Matrix Normalisasi
                    </summary>
                    <div class="px-6 pb-6">
                        <div class="overflow-x-auto mt-4">
                            <table class="w-full text-xs border-collapse">
                                <thead>
                                    <tr class="bg-gray-50 dark:bg-gray-700">
                                        <th class="border border-gray-300 dark:border-gray-600 px-3 py-2">Alternatif</th>
                                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="border border-gray-300 dark:border-gray-600 px-3 py-2">
                                            <?php echo e($kriteria->kode_kriteria); ?>

                                        </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-900 dark:text-white">
                                    <?php $__currentLoopData = $matrixNormalisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($index == 0 ? 'bg-yellow-50 dark:bg-yellow-900/20 font-semibold' : ''); ?>">
                                        <td class="border border-gray-300 dark:border-gray-600 px-3 py-2">
                                            <?php echo e($index == 0 ? 'A0 (Optimal)' : 'A' . $index . ' - ' . $row['atlet']->nama); ?>

                                        </td>
                                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="border border-gray-300 dark:border-gray-600 px-3 py-2 text-center">
                                            <?php echo e(number_format($row['C' . $kriteria->id], 4)); ?>

                                        </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Matrix Terbobot -->
                <details class="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                    <summary class="px-6 py-4 cursor-pointer font-semibold text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition">
                        ⚖️ 3. Matrix Terbobot
                    </summary>
                    <div class="px-6 pb-6">
                        <div class="overflow-x-auto mt-4">
                            <table class="w-full text-xs border-collapse">
                                <thead>
                                    <tr class="bg-gray-50 dark:bg-gray-700">
                                        <th class="border border-gray-300 dark:border-gray-600 px-3 py-2">Alternatif</th>
                                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="border border-gray-300 dark:border-gray-600 px-3 py-2">
                                            <?php echo e($kriteria->kode_kriteria); ?><br>
                                            <span class="text-xs text-gray-500">(<?php echo e($kriteria->bobot); ?>%)</span>
                                        </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-900 dark:text-white">
                                    <?php $__currentLoopData = $matrixTerbobot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($index == 0 ? 'bg-yellow-50 dark:bg-yellow-900/20 font-semibold' : ''); ?>">
                                        <td class="border border-gray-300 dark:border-gray-600 px-3 py-2">
                                            <?php echo e($index == 0 ? 'A0 (Optimal)' : 'A' . $index . ' - ' . $row['atlet']->nama); ?>

                                        </td>
                                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="border border-gray-300 dark:border-gray-600 px-3 py-2 text-center">
                                            <?php echo e(number_format($row['C' . $kriteria->id], 4)); ?>

                                        </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Nilai Optimality Function -->
                <details class="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                    <summary class="px-6 py-4 cursor-pointer font-semibold text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition">
                        🎯 4. Nilai Optimality Function (Si) dan Utility Degree (Ki)
                    </summary>
                    <div class="px-6 pb-6">
                        <div class="mt-4 space-y-4">
                            <!-- Nilai S0 -->
                            <div class="p-4 bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-500 rounded">
                                <p class="text-sm font-semibold text-gray-900 dark:text-white mb-1">
                                    Nilai Optimality Function Optimal (S0)
                                </p>
                                <p class="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                                    <?php echo e(number_format($s0, 4)); ?>

                                </p>
                            </div>

                            <!-- Tabel Si dan Ki -->
                            <div class="overflow-x-auto">
                                <table class="w-full text-sm border-collapse">
                                    <thead>
                                        <tr class="bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white">
                                            <th class="border border-gray-300 dark:border-gray-600 px-4 py-3">Ranking</th>
                                            <th class="border border-gray-300 dark:border-gray-600 px-4 py-3">Atlet</th>
                                            <th class="border border-gray-300 dark:border-gray-600 px-4 py-3">Nilai Si</th>
                                            <th class="border border-gray-300 dark:border-gray-600 px-4 py-3">Nilai Ki (Si/S0)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $hasilPerangkingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-gray-900 dark:text-white <?php echo e($hasil['ranking'] <= 3 ? 'bg-green-50 dark:bg-green-900/20' : ''); ?>">
                                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-center font-semibold">
                                                <?php echo e($hasil['ranking']); ?>

                                            </td>
                                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-3">
                                                <?php echo e($hasil['atlet']->nama); ?>

                                            </td>
                                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-center font-mono">
                                                <?php echo e(number_format($hasil['Si'], 4)); ?>

                                            </td>
                                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-center font-mono font-bold">
                                                <?php echo e(number_format($hasil['Ki'], 4)); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Rumus Penjelasan -->
                            <div class="p-4 bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 rounded">
                                <p class="text-sm text-gray-700 dark:text-gray-300">
                                    <strong>Rumus:</strong> Ki = Si / S0<br>
                                    <strong>Keterangan:</strong><br>
                                    • Ki = Utility Degree (Nilai akhir untuk perangkingan)<br>
                                    • Si = Jumlah dari nilai terbobot untuk setiap alternatif<br>
                                    • S0 = Nilai optimal (<?php echo e(number_format($s0, 4)); ?>)<br>
                                    • Semakin besar nilai Ki, semakin baik alternatif tersebut
                                </p>
                            </div>
                        </div>
                    </div>
                </details>

            </div>

            <!-- Action Buttons -->
            <div class="mt-6 flex items-center justify-between p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                <div>
                    <h4 class="font-semibold text-gray-900 dark:text-white mb-1">Perhitungan Selesai!</h4>
                    <p class="text-sm text-gray-600 dark:text-gray-400">
                        Anda dapat melihat laporan lengkap atau melakukan perhitungan ulang dengan data yang berbeda.
                    </p>
                </div>
                <div class="flex gap-3">
                    <a href="<?php echo e(route('perangkingan.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition">
                        <svg class="w-5 h-5 me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                        </svg>
                        Hitung Ulang
                    </a>
                    <a href="<?php echo e(route('laporan.index')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
                        <svg class="w-5 h-5 me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                        Lihat Laporan
                    </a>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laravel\spk-aras\resources\views/perangkingan/hasil.blade.php ENDPATH**/ ?>